@extends('layouts.admin-layout')

@section('digiadmin')
            <h1>Upload Background Image</h1>
            <input type="file" id="backgroundImageInput" accept="image/*">
            <button id="saveBackgroundButton">Save Background</button>
@endsection
