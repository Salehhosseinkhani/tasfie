

<?php $__env->startSection('digiadmin'); ?>
    <section class="section-dastgah">
        <div class="div-som-product">
            <div class="div-dastgah">
                <div class="dev-title-dastgah">
                    <h2 class="title-dastgah">خرابی دستگاه ها و پشتیبانی</h2>
                </div>
                <div class="div-input-dastgah" id="productForm-dstgah">
                <?php if($data): ?>
                    <p><strong>عنوان:</strong> <?php echo e($data['title']); ?></p>
                    <p><strong>توضیحات:</strong> <?php echo e($data['description']); ?></p>
                    <p><strong>شماره موبایل:</strong> <?php echo e($data['mobile']); ?></p>
                    <?php else: ?>
                    <p>اطلاعاتی ثبت نشده است.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\saleh hosseinkhani\Desktop\baseProject\resources\views\adminsupport.blade.php ENDPATH**/ ?>