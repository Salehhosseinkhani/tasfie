

<?php $__env->startSection('product'); ?>
<section class="section-box-product">
        <div class="div-box-product" id="box-product">
            <div class="title-box-product">
                <h1 class="title-text-box-product">قطعات تصفیه آب</h1>
            </div>
            <div class="box-product-all">
        <?php $__currentLoopData = $ghtaats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ghtaat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="box-product-one">
                        <img src="<?php echo e(asset('storage/' . $ghtaat->image)); ?>" alt="<?php echo e($ghtaat->name); ?>" class="image-box-product">
                    <h2 class="name-box-product"><?php echo e($ghtaat->name); ?></h2>
                    <p class="span-price"><?php echo e(number_format($ghtaat->price,0)); ?>

                        <span class="title-price">تومان</span>
                    </p>
                    <p class="sell-price"><?php echo e(number_format($ghtaat->sellprice,0)); ?>

                        <span class="title-price">تومان</span>
                    </p>
                    <a href="<?php echo e(route('ghtaat.add', $ghtaat->slug)); ?>"><button class="btn-blade">جزئیات بیشتر</button></a>
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.head-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\saleh hosseinkhani\Desktop\baseProject\resources\views\ghtaat.blade.php ENDPATH**/ ?>