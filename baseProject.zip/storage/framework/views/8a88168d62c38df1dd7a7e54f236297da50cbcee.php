

<?php $__env->startSection('digiadmin'); ?>
            <h1>Upload Background Image</h1>
            <input type="file" id="backgroundImageInput" accept="image/*">
            <button id="saveBackgroundButton">Save Background</button>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\saleh hosseinkhani\Desktop\baseProject\resources\views\adminbackground.blade.php ENDPATH**/ ?>