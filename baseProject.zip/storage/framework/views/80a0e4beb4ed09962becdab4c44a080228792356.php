

<?php $__env->startSection('digiadmin'); ?>

<div class="div-mghale-admin">
    <form action="<?php echo e(route('article.store')); ?>" class="form-mghale" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div>
            <label for="description">توضیحات:</label>
            <textarea id="description" name="description" required class="input-mghale"></textarea>
        </div>
        <div>
            <label for="image">عکس:</label>
            <input type="file" id="image" name="image" required class="input-mghale">
        </div>
        <button type="submit">ذخیره</button>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\saleh hosseinkhani\Desktop\baseProject\resources\views\mghaleone.blade.php ENDPATH**/ ?>