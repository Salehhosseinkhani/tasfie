

<?php $__env->startSection('product'); ?>
    <section class="support">
        <div class="div-suport">
            <div class="div-title-support">
                <h1 class="text-title-support">اعلام خرابی و پشتیبانی</h1>
            </div>
            <div class="box-support">
                    <form action="<?php echo e(route('submitForm')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="div-support">
                            <label for="title">عنوان :</label>
                            <input type="text" id="title" name="title" required class="input-support">
                        </div>
                        <div class="div-support">
                            <label for="description">توضیحات :</label>
                            <textarea id="description" name="description" required class="input-support"></textarea>
                        </div>
                        <div class="div-support">
                            <label for="mobile">شماره موبایل :</label>
                            <input type="text" id="mobile" name="mobile" required class="input-support-mobile">
                        </div>
                        <button type="submit" class="btn-support">ارسال</button>
                    </form>
                    
                    <?php if(session('success')): ?>
                        <p><?php echo e(session('success')); ?></p>
                    <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.head-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\saleh hosseinkhani\Desktop\baseProject\resources\views\form.blade.php ENDPATH**/ ?>