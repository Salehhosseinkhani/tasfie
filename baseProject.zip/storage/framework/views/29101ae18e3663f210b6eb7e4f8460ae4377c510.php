

<?php $__env->startSection('product'); ?>
<section class="section-box-product">
        <div class="div-box-product" id="box-product">
            <div class="title-box-product">
                <h1 class="title-text-box-product">فیلتر یخچال</h1>
            </div>
            <div class="box-product-all">
        <?php $__currentLoopData = $yakhchals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yakhchal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="box-product-one">
                        <img src="<?php echo e(asset('storage/' . $yakhchal->image)); ?>" alt="<?php echo e($yakhchal->name); ?>" class="image-box-product">
                    <h2 class="name-box-product"><?php echo e($yakhchal->name); ?></h2>
                    <p class="span-price"><?php echo e(number_format($yakhchal->price,0)); ?>

                        <span class="title-price">تومان</span>
                    </p>
                    <p class="sell-price"><?php echo e(number_format($yakhchal->sellprice,0)); ?>

                        <span class="title-price">تومان</span>
                    </p>
                    <a href="<?php echo e(route('yakhchal.one', $yakhchal->slug)); ?>"><button class="btn-blade">جزئیات بیشتر</button></a>
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.head-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\saleh hosseinkhani\Desktop\baseProject\resources\views\yakhchal.blade.php ENDPATH**/ ?>