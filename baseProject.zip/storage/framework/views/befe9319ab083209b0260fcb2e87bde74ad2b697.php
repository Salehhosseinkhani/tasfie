

<?php $__env->startSection('digiadmin'); ?>
        <h1>لیست سفارشات</h1>

        <?php if(session('success')): ?>
            <div style="color: green;">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="div-oreder">
            <table border="1" class="table-order">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Product Name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Name</th>
                        <th>Phone Number</th>
                        <th>Address</th>
                        <th>Postal Code</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($order->id); ?></td>
                            <td><?php echo e($order->product_name); ?></td>
                            <td><?php echo e(number_format($order->price,0)); ?></td>
                            <td><?php echo e(number_format($order->quantity,0)); ?></td>
                            <td><?php echo e($order->total); ?></td>
                            <td><?php echo e($order->name); ?></td>
                            <td><?php echo e($order->phone_number); ?></td>
                            <td><?php echo e($order->address); ?></td>
                            <td><?php echo e($order->postal_code); ?></td>
                            <td><?php echo e($order->created_at); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\saleh hosseinkhani\Desktop\baseProject\resources\views\adminorder.blade.php ENDPATH**/ ?>