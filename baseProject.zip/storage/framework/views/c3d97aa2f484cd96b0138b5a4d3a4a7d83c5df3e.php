
<div>
    <h1><?php echo e($product->name); ?></h1>
    <p><?php echo e($product->description); ?></p>
    <p>Price: <?php echo e($product->price); ?></p>
    <p>Sell Price: <?php echo e($product->sellprice); ?></p>
    <img src="<?php echo e(asset('images/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" width="300">
</div><?php /**PATH C:\Users\saleh hosseinkhani\Desktop\baseProject\resources\views\product_detail.blade.php ENDPATH**/ ?>