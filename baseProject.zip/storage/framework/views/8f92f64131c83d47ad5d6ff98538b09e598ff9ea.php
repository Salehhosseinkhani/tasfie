

<?php $__env->startSection('digiadmin'); ?>
    <section class="section-jashnvare">
        <form action="<?php echo e(route('admin.jashnvare.store')); ?>" method="POST" enctype="multipart/form-data" class="form-jashnvare">
        <?php echo csrf_field(); ?>
            <div>
                <label for="name">اسم جشنواره:</label>
                <input type="text" id="name" name="name" required class="input-jashnvare">
            </div>
            <div>
                <label for="description">توضیحات جشنواره:</label>
                <textarea id="description" name="description" required class="input-jashnvare"></textarea>
            </div>
            <div>
                <label for="image">عکس جشنواره:</label>
                <input type="file" id="image" name="image" accept="image/*" required>
            </div>
            <button type="submit">ذخیره</button>
        </form>
    </section>
<?php $__env->stopSection(); ?>
















<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\saleh hosseinkhani\Desktop\baseProject\resources\views\adminjashnvare.blade.php ENDPATH**/ ?>